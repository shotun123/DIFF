//
//  main.c
//  diff
//
//  Created by William McCarthy on 274//20.
//  Copyright © 2020 William McCarthy. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
  // insert code here...
  printf("Hello, World!\n");
  return 0;
}
